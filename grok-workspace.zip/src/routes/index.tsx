import { createFileRoute } from "@tanstack/react-router";
import { WeatherApp } from "@/components/weather/WeatherApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <WeatherApp />;
}
