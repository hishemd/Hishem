import {
  Cloud,
  CloudFog,
  CloudLightning,
  CloudRain,
  CloudSnow,
  CloudSun,
  Moon,
  Sun,
} from "lucide-react";
import { isRainCode, isSnowCode } from "@/lib/weather/scenes";

export function WeatherGlyph({
  code,
  isDay,
  className,
}: {
  code: number;
  isDay: boolean;
  className?: string;
}) {
  const Icon =
    code >= 95
      ? CloudLightning
      : code === 45 || code === 48
        ? CloudFog
        : isSnowCode(code)
          ? CloudSnow
          : isRainCode(code)
            ? CloudRain
            : code === 3
              ? Cloud
              : code === 1 || code === 2
                ? isDay
                  ? CloudSun
                  : Cloud
                : isDay
                  ? Sun
                  : Moon;
  return <Icon className={className} strokeWidth={1.7} aria-hidden="true" />;
}
