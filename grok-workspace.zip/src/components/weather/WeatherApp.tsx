import { useEffect, useState, type ReactNode } from "react";
import {
  Cloud,
  CloudFog,
  CloudLightning,
  CloudRain,
  CloudSnow,
  CloudSun,
  Droplets,
  Locate,
  MapPin,
  Moon,
  Pause,
  Play,
  Sun,
  SunMedium,
  Sunrise,
  Sunset,
  Thermometer,
  Wind,
  X,
} from "lucide-react";
import { fetchForecast, reversePlace, searchCities } from "@/lib/weather/api";
import { conditionText, copyOf } from "@/lib/weather/copy";
import {
  clockFace,
  clockFromIso,
  dateLabel,
  dayName,
  hourLabel,
  tempOf,
  uvText,
  windText,
} from "@/lib/weather/format";
import { placeCountry, placeTitle, PRESETS, toPlace } from "@/lib/weather/places";
import {
  discKind,
  guessScene,
  SCENE_META,
  sceneFromWeather,
  visualHour,
  type SceneId,
} from "@/lib/weather/scenes";
import { useHalo, usePersistHalo } from "@/lib/weather/store";
import type { Forecast, Place } from "@/lib/weather/types";
import { ClockPlaceholder, FlipClock } from "@/components/weather/FlipClock";
import { WeatherGlyph } from "@/components/weather/WeatherGlyph";
import { WeatherScene } from "@/components/weather/WeatherScene";

function SceneIcon({ id }: { id: SceneId }) {
  const className = "size-5";
  switch (id) {
    case "clear-day":
      return <Sun className={className} />;
    case "partly-day":
      return <CloudSun className={className} />;
    case "cloudy-day":
    case "cloudy-night":
      return <Cloud className={className} />;
    case "rain-day":
    case "rain-night":
      return <CloudRain className={className} />;
    case "storm":
      return <CloudLightning className={className} />;
    case "snow-day":
    case "snow-night":
      return <CloudSnow className={className} />;
    case "fog":
      return <CloudFog className={className} />;
    case "wind":
      return <Wind className={className} />;
    default:
      return <Moon className={className} />;
  }
}

export function WeatherApp() {
  usePersistHalo();
  const lang = useHalo((state) => state.lang);
  const unit = useHalo((state) => state.unit);
  const place = useHalo((state) => state.place);
  const recent = useHalo((state) => state.recent);
  const setLang = useHalo((state) => state.setLang);
  const setUnit = useHalo((state) => state.setUnit);
  const setPlace = useHalo((state) => state.setPlace);
  const copy = copyOf(lang);

  const [now, setNow] = useState<Date | null>(null);
  const [pack, setPack] = useState<{ id: string; data: Forecast } | null>(null);
  const [errorId, setErrorId] = useState<string | null>(null);
  const [nonce, setNonce] = useState(0);
  const [sheet, setSheet] = useState(false);
  const [sceneOverride, setSceneOverride] = useState<SceneId | null>(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    setNow(new Date());
    const timer = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    document.title = `Halo · ${placeTitle(place, lang)}`;
  }, [place, lang]);

  useEffect(() => {
    const controller = new AbortController();
    let ignore = false;
    setErrorId((current) => (current === place.id ? null : current));
    fetchForecast(place.latitude, place.longitude, controller.signal)
      .then((data) => {
        if (ignore) return;
        setPack({ id: place.id, data });
        setErrorId(null);
      })
      .catch((error: unknown) => {
        if (ignore) return;
        if (error instanceof Error && error.name === "AbortError") return;
        setErrorId(place.id);
      });
    return () => {
      ignore = true;
      controller.abort();
    };
  }, [place.id, place.latitude, place.longitude, nonce]);

  useEffect(() => {
    if (!playing) return;
    const timer = window.setInterval(() => {
      setSceneOverride((current) => {
        const ids = SCENE_META.map((item) => item.id);
        const index = current ? ids.indexOf(current) : -1;
        return ids[(index + 1) % ids.length] ?? "clear-day";
      });
    }, 7000);
    return () => window.clearInterval(timer);
  }, [playing]);

  const forecast = pack?.id === place.id ? pack.data : null;
  const showError = !forecast && errorId === place.id;
  const timeZone = forecast?.timezone || place.timezone;
  const face = now ? clockFace(now, timeZone, lang) : null;
  const hour = face?.hourFloat ?? 12;
  const liveScene = forecast
    ? sceneFromWeather(forecast.current.code, forecast.current.isDay, forecast.current.wind)
    : face
      ? guessScene(face.hourFloat)
      : "pending";
  const scene = sceneOverride ?? liveScene;
  const skyHour = face ? visualHour(scene, face.hourFloat) : 17.6;
  const today = forecast?.daily[0];
  const weekMin = forecast ? Math.min(...forecast.daily.map((day) => day.min)) : 0;
  const weekMax = forecast ? Math.max(...forecast.daily.map((day) => day.max)) : 1;
  const span = Math.max(1, weekMax - weekMin);
  const kind = discKind(
    forecast?.current.code ?? 0,
    forecast?.current.isDay ?? (hour > 6 && hour < 18),
  );

  function choose(next: Place) {
    setPlace(next);
    setSheet(false);
    setPlaying(false);
    setSceneOverride(null);
  }

  function pickScene(id: SceneId | null) {
    setPlaying(false);
    setSceneOverride(id);
  }

  function togglePlay() {
    if (playing) {
      setPlaying(false);
      return;
    }
    setSceneOverride((current) => current ?? SCENE_META[0]!.id);
    setPlaying(true);
  }

  const unitLabel = unit === "c" ? (lang === "ar" ? "°م" : "°C") : lang === "ar" ? "°ف" : "°F";

  return (
    <div className="app-shell" dir={lang === "ar" ? "rtl" : "ltr"} lang={lang}>
      <WeatherScene scene={scene} hour={skyHour} />
      <main className="app-scroll">
        <div className="stage">
          <header className="rise">
            <div className="flex items-center justify-between gap-2">
              <h1 className="wordmark">Halo</h1>
              <div className="flex gap-2">
                <button
                  type="button"
                  className="chip"
                  aria-label={unit === "c" ? copy.toF : copy.toC}
                  onClick={() => setUnit(unit === "c" ? "f" : "c")}
                >
                  {unitLabel}
                </button>
                <button
                  type="button"
                  className="chip"
                  aria-label={copy.switchLang}
                  onClick={() => setLang(lang === "ar" ? "en" : "ar")}
                >
                  {lang === "ar" ? "EN" : "عربي"}
                </button>
              </div>
            </div>
            <button type="button" className="chip mt-3 max-w-full min-w-0" onClick={() => setSheet(true)}>
              <MapPin className="size-4 shrink-0" aria-hidden="true" />
              <span className="truncate">{placeTitle(place, lang)}</span>
              <span className="truncate text-xs text-muted">{placeCountry(place, lang)}</span>
            </button>
          </header>

          <div className="rise flex justify-center">
            {face ? (
              <FlipClock hours={face.hours} minutes={face.minutes} period={face.period} />
            ) : (
              <ClockPlaceholder />
            )}
          </div>

          <section className="plaque rise">
            <div className="wx-disc" data-kind={showError ? "cloud" : kind}>
              {forecast ? (
                <WeatherGlyph code={forecast.current.code} isDay={forecast.current.isDay} className="size-7" />
              ) : (
                <CloudSun className="size-7" aria-hidden="true" />
              )}
            </div>
            {showError ? (
              <div className="flex flex-col items-start gap-3 pt-2">
                <p className="text-base font-medium">{copy.error}</p>
                <button type="button" className="chip" onClick={() => setNonce((value) => value + 1)}>
                  {copy.retry}
                </button>
              </div>
            ) : (
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 pt-1">
                  <p className="truncate text-lg font-medium">
                    {forecast ? conditionText(forecast.current.code, lang) : copy.loading}
                  </p>
                  <p className="text-sm text-muted">{face ? dateLabel(now ?? new Date(), timeZone, lang) : " "}</p>
                  {sceneOverride ? <p className="text-xs text-accent">{copy.previewing}</p> : null}
                </div>
                <div className="shrink-0 text-end">
                  {forecast ? (
                    <p className="font-display text-5xl font-light leading-none tabular-nums">
                      {tempOf(forecast.current.temperature, unit)}°
                    </p>
                  ) : (
                    <span className="skel" />
                  )}
                  <p className="mt-1 text-sm text-muted tabular-nums">
                    {today ? `${tempOf(today.max, unit)}° / ${tempOf(today.min, unit)}°` : "—"}
                  </p>
                </div>
              </div>
            )}
          </section>

          <section className="grid grid-cols-2 gap-2">
            <Stat
              icon={<Thermometer className="size-3.5" />}
              label={copy.feels}
              value={forecast ? `${tempOf(forecast.current.apparent, unit)}°` : "—"}
            />
            <Stat
              icon={<Droplets className="size-3.5" />}
              label={copy.humidity}
              value={forecast ? `${Math.round(forecast.current.humidity)}%` : "—"}
            />
            <Stat
              icon={<Wind className="size-3.5" />}
              label={copy.wind}
              value={forecast ? windText(forecast.current.wind, unit, lang) : "—"}
            />
            <Stat
              icon={<SunMedium className="size-3.5" />}
              label={copy.uv}
              value={uvText(today?.uv ?? null)}
            />
          </section>

          {today ? (
            <div className="stat stat-row">
              <span className="inline-flex items-center gap-2 text-sm">
                <Sunrise className="size-4 text-accent" aria-hidden="true" />
                {clockFromIso(today.sunrise, lang)}
              </span>
              <span className="inline-flex items-center gap-2 text-sm">
                <Sunset className="size-4 text-accent" aria-hidden="true" />
                {clockFromIso(today.sunset, lang)}
              </span>
            </div>
          ) : null}

          <section>
            <h2 className="mb-2 text-sm font-medium">{copy.hourly}</h2>
            <div className="hour-row">
              {(forecast?.hourly ?? []).map((point) => (
                <div key={point.time} className="hour-card">
                  <span className="text-xs text-muted">{hourLabel(point.time, lang)}</span>
                  <WeatherGlyph code={point.code} isDay={point.isDay} className="size-5" />
                  <span className="text-sm font-medium tabular-nums">{tempOf(point.temp, unit)}°</span>
                </div>
              ))}
            </div>
          </section>

          <section className="panel">
            <h2 className="px-1 py-2 text-sm font-medium">{copy.daily}</h2>
            {(forecast?.daily ?? []).map((day, index) => {
              const start = ((day.min - weekMin) / span) * 100;
              const width = Math.max(8, ((day.max - day.min) / span) * 100);
              return (
                <div key={day.date} className="day-row">
                  <span className="truncate text-sm">{dayName(day.date, index, lang)}</span>
                  <WeatherGlyph code={day.code} isDay className="size-4" />
                  <span className="text-center text-xs text-muted tabular-nums">{tempOf(day.min, unit)}°</span>
                  <span className="range" aria-hidden="true">
                    <i style={{ insetInlineStart: `${start}%`, width: `${Math.min(width, 100 - start)}%` }} />
                  </span>
                  <span className="text-center text-xs font-medium tabular-nums">{tempOf(day.max, unit)}°</span>
                </div>
              );
            })}
          </section>
        </div>
      </main>

      <nav className="dock" aria-label={copy.scenes}>
        <div className="dock-scroll" role="radiogroup" aria-label={copy.scenes}>
          <button
            type="button"
            className="scene-btn icon-only"
            aria-pressed={playing}
            aria-label={playing ? copy.tourStop : copy.tour}
            onClick={togglePlay}
          >
            {playing ? <Pause className="size-5" /> : <Play className="size-5" />}
          </button>
          <button
            type="button"
            className="scene-btn"
            role="radio"
            aria-checked={sceneOverride === null}
            onClick={() => pickScene(null)}
          >
            <i className="live-dot" />
            <span>{copy.now}</span>
          </button>
          {SCENE_META.map((item) => (
            <button
              key={item.id}
              type="button"
              className="scene-btn"
              role="radio"
              aria-checked={sceneOverride === item.id}
              onClick={() => pickScene(item.id)}
            >
              <SceneIcon id={item.id} />
              <span>{lang === "ar" ? item.ar : item.en}</span>
            </button>
          ))}
        </div>
      </nav>

      {sheet ? (
        <CitySheet
          lang={lang}
          recent={recent.filter((item) => item.id !== place.id)}
          onClose={() => setSheet(false)}
          onChoose={choose}
        />
      ) : null}
    </div>
  );
}

function Stat({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return (
    <div className="stat">
      <span className="inline-flex items-center gap-1 text-xs text-muted">
        {icon}
        {label}
      </span>
      <span className="text-lg font-medium tabular-nums">{value}</span>
    </div>
  );
}

function CitySheet({
  lang,
  recent,
  onClose,
  onChoose,
}: {
  lang: "ar" | "en";
  recent: Place[];
  onClose: () => void;
  onChoose: (place: Place) => void;
}) {
  const copy = copyOf(lang);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Place[]>([]);
  const [note, setNote] = useState<string | null>(null);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  }, [onClose]);

  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults([]);
      return;
    }
    const controller = new AbortController();
    const timer = window.setTimeout(() => {
      searchCities(trimmed, lang, controller.signal)
        .then(setResults)
        .catch((error: unknown) => {
          if (error instanceof Error && error.name === "AbortError") return;
          setResults([]);
        });
    }, 280);
    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [query, lang]);

  async function locate() {
    if (!navigator.geolocation) {
      setNote(copy.geoFailed);
      return;
    }
    setNote(copy.geoWorking);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const found = await reversePlace(position.coords.latitude, position.coords.longitude, lang).catch(
          () => null,
        );
        onChoose(
          found ?? {
            id: `${position.coords.latitude.toFixed(2)},${position.coords.longitude.toFixed(2)}`,
            name: copy.myLocation,
            country: "",
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
          },
        );
      },
      () => setNote(copy.geoDenied),
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 60000 },
    );
  }

  return (
    <div className="sheet-back" onClick={onClose}>
      <div
        className="sheet"
        role="dialog"
        aria-modal="true"
        aria-label={copy.search}
        onClick={(event) => event.stopPropagation()}
      >
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-lg font-medium">{copy.search}</h2>
          <button type="button" className="chip icon-only" aria-label={copy.close} onClick={onClose}>
            <X className="size-4" />
          </button>
        </div>
        <form
          onSubmit={(event) => {
            event.preventDefault();
            const first = results[0];
            if (first) onChoose(first);
          }}
        >
          <div className="search-wrap">
            <MapPin className="size-4" aria-hidden="true" />
            <input
              className="city-input"
              autoFocus
              value={query}
              placeholder={copy.searchPh}
              aria-label={copy.search}
              onChange={(event) => setQuery(event.target.value)}
            />
          </div>
        </form>
        <button type="button" className="chip mt-3" onClick={() => void locate()}>
          <Locate className="size-4" aria-hidden="true" />
          {copy.locate}
        </button>
        {note ? <p className="mt-2 text-sm text-muted">{note}</p> : null}

        {query.trim().length >= 2 ? (
          <ul className="city-list">
            {results.length === 0 ? <li className="text-sm text-muted">{copy.noResults}</li> : null}
            {results.map((item) => (
              <li key={item.id}>
                <button type="button" className="city-hit" onClick={() => onChoose(item)}>
                  <span>{item.name}</span>
                  <span className="text-xs text-muted">{item.country}</span>
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <>
            {recent.length > 0 ? (
              <>
                <p className="mb-2 mt-4 text-sm text-muted">{copy.recent}</p>
                <ul className="city-list">
                  {recent.map((item) => (
                    <li key={item.id}>
                      <button type="button" className="city-hit" onClick={() => onChoose(item)}>
                        <span>{placeTitle(item, lang)}</span>
                        <span className="text-xs text-muted">{placeCountry(item, lang)}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              </>
            ) : null}
            <p className="mb-2 mt-4 text-sm text-muted">{copy.cities}</p>
            <ul className="city-list">
              {PRESETS.map((preset) => (
                <li key={preset.id}>
                  <button type="button" className="city-hit" onClick={() => onChoose(toPlace(preset, lang))}>
                    <span>{lang === "ar" ? preset.nameAr : preset.nameEn}</span>
                    <span className="text-xs text-muted">{lang === "ar" ? preset.countryAr : preset.countryEn}</span>
                  </button>
                </li>
              ))}
            </ul>
          </>
        )}
      </div>
    </div>
  );
}
