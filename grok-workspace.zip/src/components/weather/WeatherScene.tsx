import type { CSSProperties } from "react";
import type { SceneId } from "@/lib/weather/scenes";

function rnd(index: number, salt: number) {
  const value = Math.sin(index * 127.1 + salt * 311.7) * 43758.5453;
  return value - Math.floor(value);
}

function sunPoint(hour: number) {
  const t = Math.min(1, Math.max(0, (hour - 6.1) / 12.2));
  return {
    left: `${(10 + 80 * t).toFixed(1)}%`,
    top: `${(46 - Math.sin(t * Math.PI) * 30).toFixed(1)}%`,
  };
}

function moonPoint(hour: number) {
  const shifted = hour < 16 ? hour + 24 : hour;
  const t = Math.min(1, Math.max(0, (shifted - 18) / 12));
  return {
    left: `${(14 + 70 * t).toFixed(1)}%`,
    top: `${(32 - Math.sin(t * Math.PI) * 14).toFixed(1)}%`,
  };
}

type Building = { x: number; w: number; h: number };

function makeBuildings() {
  const buildings: Building[] = [];
  let x = 0;
  for (let index = 0; x < 1440 && index < 42; index += 1) {
    const w = 36 + Math.floor(rnd(index, 1) * 52);
    const h = 48 + Math.floor(rnd(index, 2) * 168);
    buildings.push({ x, w, h });
    x += w - 1;
  }
  return buildings;
}

const BUILDINGS = makeBuildings();

const WINDOWS = BUILDINGS.flatMap((building, index) => {
  const count = 2 + Math.floor(rnd(index, 4) * 5);
  return Array.from({ length: count }, (_, key) => ({
    x: building.x + 6 + rnd(index * 19 + key, 5) * Math.max(6, building.w - 16),
    y: 400 - building.h + 10 + rnd(index * 19 + key, 6) * Math.max(6, building.h - 22),
    id: `${index}-${key}`,
  }));
});

const FAR_SPOTS = [4, 17, 30, 43];
const NEAR_SPOTS = [8, 22, 36, 47];

function CloudBand({ variant }: { variant: "far" | "near" }) {
  const spots = variant === "far" ? FAR_SPOTS : NEAR_SPOTS;
  const all = [...spots, ...spots.map((spot) => spot + 50)];
  return (
    <div className={`cloud-band ${variant}`}>
      {all.map((left, index) => {
        const seed = index % spots.length;
        const width = (variant === "far" ? 22 : 30) + rnd(seed, 3) * 16;
        const height = (variant === "far" ? 11 : 14) + rnd(seed, 4) * 7;
        return (
          <i
            key={`${variant}-${left}`}
            className="cloud"
            style={{
              left: `${left}%`,
              top: `${6 + rnd(seed, variant === "far" ? 2 : 7) * 48}%`,
              width: `${width}vw`,
              height: `${height}vw`,
            }}
          />
        );
      })}
    </div>
  );
}

export function WeatherScene({ scene, hour }: { scene: SceneId; hour: number }) {
  const sun = sunPoint(hour);
  const moon = moonPoint(hour);
  const sunStyle = { left: sun.left, top: sun.top } as CSSProperties;
  const moonStyle = { left: moon.left, top: moon.top } as CSSProperties;

  return (
    <div className={`sky scene-${scene}`} aria-hidden="true">
      <div className="sky-fill" />
      <div className="stars">
        {Array.from({ length: 42 }, (_, index) => (
          <i
            key={index}
            className={rnd(index, 9) > 0.86 ? "star big" : "star"}
            style={{
              left: `${rnd(index, 1) * 100}%`,
              top: `${rnd(index, 2) * 58}%`,
              animationDelay: `${-rnd(index, 3) * 4}s`,
            }}
          />
        ))}
      </div>
      <div className="horizon-glow" style={{ left: sun.left }} />
      <div className="sun" style={sunStyle}>
        <div className="sun-glow" />
        <div className="rays" />
        <div className="disc" />
      </div>
      <div className="moon" style={moonStyle}>
        <div className="moon-glow" />
        <div className="moon-disc">
          <i className="crater c1" />
          <i className="crater c2" />
          <i className="crater c3" />
        </div>
      </div>
      <CloudBand variant="far" />
      <CloudBand variant="near" />
      <svg className="hills back" viewBox="0 0 1440 360" preserveAspectRatio="none">
        <path
          className="hill far"
          d="M0 158 C140 96 260 188 400 132 C560 68 700 176 880 124 C1060 70 1220 160 1440 108 L1440 360 L0 360 Z"
        />
        <path
          className="hill mid"
          d="M0 206 C170 156 320 236 500 186 C720 128 880 228 1100 176 C1260 146 1360 196 1440 168 L1440 360 L0 360 Z"
        />
      </svg>
      <svg className="skyline" viewBox="0 0 1440 400" preserveAspectRatio="xMidYMax slice">
        {BUILDINGS.map((building) => (
          <rect
            key={`${building.x}`}
            className="bldg"
            x={building.x}
            y={400 - building.h}
            width={building.w - 3}
            height={building.h}
          />
        ))}
        <g className="wins">
          {WINDOWS.map((window) => (
            <rect key={window.id} className="win" x={window.x} y={window.y} width="3.2" height="4.2" rx="0.4" />
          ))}
        </g>
      </svg>
      <svg className="hills front" viewBox="0 0 1440 360" preserveAspectRatio="none">
        <path
          className="hill near"
          d="M0 236 C210 196 380 286 580 238 C820 184 1020 276 1240 226 C1340 206 1390 236 1440 214 L1440 360 L0 360 Z"
        />
      </svg>
      <div className="rain l1" />
      <div className="rain l2" />
      <div className="rain l3" />
      <div className="splashes" />
      <div className="snow">
        {Array.from({ length: 34 }, (_, index) => {
          const size = 2 + rnd(index, 4) * 5;
          return (
            <i
              key={index}
              className="flake"
              style={{
                left: `${rnd(index, 1) * 100}%`,
                width: size,
                height: size,
                animationDuration: `${8 + rnd(index, 2) * 10}s`,
                animationDelay: `${-rnd(index, 3) * 14}s`,
                opacity: 0.45 + rnd(index, 5) * 0.55,
              }}
            />
          );
        })}
      </div>
      <div className="leaf-field">
        {Array.from({ length: 14 }, (_, index) => (
          <i
            key={index}
            className={`leaf tone-${index % 4}`}
            style={{
              top: `${8 + rnd(index, 2) * 62}%`,
              animationDuration: `${6 + rnd(index, 3) * 7}s`,
              animationDelay: `${-rnd(index, 4) * 9}s`,
            }}
          />
        ))}
      </div>
      <div className="fog f1" />
      <div className="fog f2" />
      <svg className="bolt b1" viewBox="0 0 80 180">
        <polygon points="46,0 20,74 38,74 12,168 64,66 42,66 70,0" />
      </svg>
      <svg className="bolt b2" viewBox="0 0 80 180">
        <polygon points="40,0 16,80 34,80 18,170 66,72 44,72 68,0" />
      </svg>
      <div className="flash" />
      <div className="glass">
        {Array.from({ length: 12 }, (_, index) => (
          <i
            key={index}
            className="gdrop"
            style={{
              left: `${8 + rnd(index, 1) * 84}%`,
              top: `${12 + rnd(index, 2) * 70}%`,
              width: 5 + rnd(index, 3) * 9,
              height: 7 + rnd(index, 4) * 12,
            }}
          />
        ))}
      </div>
      <div className="wiper" />
      <div className="vignette" />
    </div>
  );
}
