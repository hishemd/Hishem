import { useEffect, useRef, useState } from "react";

function prefersReduced() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function FlipCard({ value, period }: { value: string; period?: string }) {
  const shownRef = useRef(value);
  const seq = useRef(0);
  const [shown, setShown] = useState(value);
  const [flop, setFlop] = useState<{ from: string; to: string; key: number } | null>(null);

  useEffect(() => {
    if (value === shownRef.current) return;
    const from = shownRef.current;
    if (prefersReduced()) {
      shownRef.current = value;
      setShown(value);
      setFlop(null);
      return;
    }
    const key = ++seq.current;
    setFlop({ from, to: value, key });
    const timer = window.setTimeout(() => {
      shownRef.current = value;
      setShown(value);
      setFlop(null);
    }, 520);
    return () => window.clearTimeout(timer);
  }, [value]);

  const top = flop ? flop.to : shown;
  const bottom = flop ? flop.from : shown;

  return (
    <div className="flip-card">
      <div className="half top" aria-hidden="true">
        <span className="num">{top}</span>
      </div>
      <div className="half bottom" aria-hidden="true">
        <span className="num">{bottom}</span>
      </div>
      {flop ? (
        <>
          <div key={`${flop.key}-a`} className="leaf top play">
            <span className="num">{flop.from}</span>
            <i className="shade" />
          </div>
          <div key={`${flop.key}-b`} className="leaf bottom play">
            <span className="num">{flop.to}</span>
            <i className="shade" />
          </div>
        </>
      ) : null}
      {period ? <span className="period">{period}</span> : null}
    </div>
  );
}

export function FlipClock({
  hours,
  minutes,
  period,
}: {
  hours: string;
  minutes: string;
  period: string;
}) {
  return (
    <div className="flip-row" dir="ltr" role="group" aria-label={`${hours}:${minutes} ${period}`}>
      <FlipCard value={hours} />
      <FlipCard value={minutes} period={period} />
    </div>
  );
}

export function ClockPlaceholder() {
  return (
    <div className="flip-row" aria-hidden="true">
      <div className="flip-card" />
      <div className="flip-card" />
    </div>
  );
}
