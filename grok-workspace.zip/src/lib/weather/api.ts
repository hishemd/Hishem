import type { Forecast, Lang, Place } from "@/lib/weather/types";

type GeoResult = {
  name: string;
  country?: string;
  admin1?: string;
  latitude: number;
  longitude: number;
  timezone?: string;
};

function mapGeo(result: GeoResult): Place {
  return {
    id: `${result.latitude.toFixed(2)},${result.longitude.toFixed(2)}`,
    name: result.name,
    country: result.admin1 ? `${result.country ?? ""} · ${result.admin1}` : (result.country ?? ""),
    latitude: result.latitude,
    longitude: result.longitude,
    timezone: result.timezone || "UTC",
  };
}

export async function searchCities(query: string, lang: Lang, signal: AbortSignal) {
  const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
  url.searchParams.set("name", query);
  url.searchParams.set("count", "6");
  url.searchParams.set("language", lang);
  url.searchParams.set("format", "json");
  const response = await fetch(url, { signal });
  if (!response.ok) throw new Error("search failed");
  const data = (await response.json()) as { results?: GeoResult[] };
  return (data.results ?? []).map(mapGeo);
}

export async function reversePlace(latitude: number, longitude: number, lang: Lang) {
  const url = new URL("https://geocoding-api.open-meteo.com/v1/reverse");
  url.searchParams.set("latitude", String(latitude));
  url.searchParams.set("longitude", String(longitude));
  url.searchParams.set("language", lang);
  const response = await fetch(url);
  if (!response.ok) return null;
  const data = (await response.json()) as { results?: GeoResult[] };
  const first = data.results?.[0];
  return first ? mapGeo(first) : null;
}

export async function fetchForecast(latitude: number, longitude: number, signal: AbortSignal): Promise<Forecast> {
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", String(latitude));
  url.searchParams.set("longitude", String(longitude));
  url.searchParams.set(
    "current",
    "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m",
  );
  url.searchParams.set("hourly", "temperature_2m,weather_code,precipitation_probability,is_day");
  url.searchParams.set(
    "daily",
    "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max",
  );
  url.searchParams.set("timezone", "auto");
  url.searchParams.set("forecast_days", "7");
  url.searchParams.set("wind_speed_unit", "kmh");
  const response = await fetch(url, { signal });
  if (!response.ok) throw new Error("forecast failed");
  const data = (await response.json()) as {
    timezone?: string;
    current?: {
      time: string;
      temperature_2m: number;
      apparent_temperature: number;
      relative_humidity_2m: number;
      weather_code: number;
      is_day: number;
      wind_speed_10m: number;
    };
    hourly?: {
      time: string[];
      temperature_2m: number[];
      weather_code: number[];
      precipitation_probability: number[];
      is_day: number[];
    };
    daily?: {
      time: string[];
      weather_code: number[];
      temperature_2m_max: number[];
      temperature_2m_min: number[];
      sunrise: string[];
      sunset: string[];
      uv_index_max?: Array<number | null>;
      precipitation_probability_max?: Array<number | null>;
    };
  };
  if (!data.current || !data.hourly || !data.daily) throw new Error("forecast failed");
  const current = data.current;
  const hourly = data.hourly;
  const daily = data.daily;
  const stamp = current.time.slice(0, 13);
  let start = hourly.time.findIndex((time) => time.slice(0, 13) >= stamp);
  if (start < 0) start = 0;
  const hours = [];
  for (let index = start; index < Math.min(hourly.time.length, start + 24); index += 1) {
    hours.push({
      time: hourly.time[index] ?? "",
      temp: hourly.temperature_2m[index] ?? 0,
      code: hourly.weather_code[index] ?? 0,
      pop: hourly.precipitation_probability[index] ?? 0,
      isDay: Boolean(hourly.is_day[index]),
    });
  }
  return {
    timezone: data.timezone || "UTC",
    current: {
      temperature: current.temperature_2m,
      apparent: current.apparent_temperature,
      humidity: current.relative_humidity_2m,
      code: current.weather_code,
      isDay: Boolean(current.is_day),
      wind: current.wind_speed_10m,
    },
    hourly: hours,
    daily: daily.time.map((date, index) => ({
      date,
      code: daily.weather_code[index] ?? 0,
      max: daily.temperature_2m_max[index] ?? 0,
      min: daily.temperature_2m_min[index] ?? 0,
      pop: daily.precipitation_probability_max?.[index] ?? 0,
      uv: daily.uv_index_max?.[index] ?? null,
      sunrise: daily.sunrise[index] ?? "",
      sunset: daily.sunset[index] ?? "",
    })),
  };
}
