import type { Lang, Unit } from "@/lib/weather/types";

function locale(lang: Lang) {
  return lang === "ar" ? "ar-SA-u-nu-latn" : "en-US";
}

export function zonedHour(date: Date, timeZone: string) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  const pick = (type: string) => Number(parts.find((part) => part.type === type)?.value ?? "0");
  let hour = pick("hour");
  if (hour === 24) hour = 0;
  const minute = pick("minute");
  return { hour, minute, hourFloat: hour + minute / 60 };
}

export function clockFace(date: Date, timeZone: string, lang: Lang) {
  const zoned = zonedHour(date, timeZone);
  const period = zoned.hour < 12 ? (lang === "ar" ? "ص" : "AM") : lang === "ar" ? "م" : "PM";
  const h12 = zoned.hour % 12 || 12;
  return {
    hours: String(h12).padStart(2, "0"),
    minutes: String(zoned.minute).padStart(2, "0"),
    period,
    hourFloat: zoned.hourFloat,
  };
}

export function dateLabel(date: Date, timeZone: string, lang: Lang) {
  return new Intl.DateTimeFormat(locale(lang), {
    weekday: "short",
    day: "numeric",
    month: "short",
    timeZone,
  }).format(date);
}

export function dayName(iso: string, index: number, lang: Lang) {
  if (index === 0) return lang === "ar" ? "اليوم" : "Today";
  if (index === 1) return lang === "ar" ? "غداً" : "Tomorrow";
  const [year, month, day] = iso.split("-").map(Number);
  const utc = new Date(Date.UTC(year ?? 2026, (month ?? 1) - 1, day ?? 1, 12));
  return new Intl.DateTimeFormat(locale(lang), { weekday: "short", timeZone: "UTC" }).format(utc);
}

export function hourLabel(iso: string, lang: Lang) {
  const hour = Number(iso.slice(11, 13));
  const h12 = hour % 12 || 12;
  const period = hour < 12 ? (lang === "ar" ? "ص" : "AM") : lang === "ar" ? "م" : "PM";
  return `${h12} ${period}`;
}

export function clockFromIso(iso: string, lang: Lang) {
  const hour = Number(iso.slice(11, 13));
  const minute = iso.slice(14, 16);
  const h12 = hour % 12 || 12;
  const period = hour < 12 ? (lang === "ar" ? "ص" : "AM") : lang === "ar" ? "م" : "PM";
  return `${h12}:${minute} ${period}`;
}

export function tempOf(celsius: number, unit: Unit) {
  const value = unit === "f" ? (celsius * 9) / 5 + 32 : celsius;
  return Math.round(value);
}

export function windText(kmh: number, unit: Unit, lang: Lang) {
  if (unit === "f") {
    return `${Math.round(kmh * 0.621371)} ${lang === "ar" ? "ميل/س" : "mph"}`;
  }
  return `${Math.round(kmh)} ${lang === "ar" ? "كم/س" : "km/h"}`;
}

export function uvText(uv: number | null) {
  if (uv == null || Number.isNaN(uv)) return "—";
  return uv >= 10 ? String(Math.round(uv)) : uv.toFixed(1);
}
