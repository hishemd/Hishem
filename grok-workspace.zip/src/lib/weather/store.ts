import { useEffect } from "react";
import { create } from "zustand";
import { DEFAULT_PLACE } from "@/lib/weather/places";
import type { Lang, Place, Unit } from "@/lib/weather/types";

const KEY = "halo-weather-v1";

type HaloState = {
  lang: Lang;
  unit: Unit;
  place: Place;
  recent: Place[];
  setLang: (lang: Lang) => void;
  setUnit: (unit: Unit) => void;
  setPlace: (place: Place) => void;
};

function isPlace(value: unknown): value is Place {
  if (!value || typeof value !== "object") return false;
  const place = value as Place;
  return (
    typeof place.id === "string" &&
    typeof place.name === "string" &&
    typeof place.country === "string" &&
    typeof place.latitude === "number" &&
    typeof place.longitude === "number" &&
    typeof place.timezone === "string"
  );
}

export const useHalo = create<HaloState>((set) => ({
  lang: "ar",
  unit: "c",
  place: DEFAULT_PLACE,
  recent: [],
  setLang: (lang) => set({ lang }),
  setUnit: (unit) => set({ unit }),
  setPlace: (place) =>
    set((state) => ({
      place,
      recent: [place, ...state.recent.filter((item) => item.id !== place.id)].slice(0, 5),
    })),
}));

export function usePersistHalo() {
  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as Partial<HaloState>;
        const place = isPlace(parsed.place) ? parsed.place : null;
        if (place) {
          const recent = Array.isArray(parsed.recent) ? parsed.recent.filter(isPlace).slice(0, 5) : [];
          useHalo.setState({
            lang: parsed.lang === "en" ? "en" : "ar",
            unit: parsed.unit === "f" ? "f" : "c",
            place,
            recent,
          });
        }
      }
    } catch {
      /* ignore broken storage */
    }
    return useHalo.subscribe((state) => {
      localStorage.setItem(
        KEY,
        JSON.stringify({
          lang: state.lang,
          unit: state.unit,
          place: state.place,
          recent: state.recent,
        }),
      );
    });
  }, []);
}
