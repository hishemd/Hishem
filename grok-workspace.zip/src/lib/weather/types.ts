export type Lang = "ar" | "en";
export type Unit = "c" | "f";

export type Place = {
  id: string;
  name: string;
  country: string;
  latitude: number;
  longitude: number;
  timezone: string;
};

export type CurrentWeather = {
  temperature: number;
  apparent: number;
  humidity: number;
  code: number;
  isDay: boolean;
  wind: number;
};

export type HourPoint = {
  time: string;
  temp: number;
  code: number;
  pop: number;
  isDay: boolean;
};

export type DayPoint = {
  date: string;
  code: number;
  max: number;
  min: number;
  pop: number;
  uv: number | null;
  sunrise: string;
  sunset: string;
};

export type Forecast = {
  timezone: string;
  current: CurrentWeather;
  hourly: HourPoint[];
  daily: DayPoint[];
};
