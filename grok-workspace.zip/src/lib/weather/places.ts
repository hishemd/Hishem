import type { Lang, Place } from "@/lib/weather/types";

export type Preset = {
  id: string;
  nameAr: string;
  nameEn: string;
  countryAr: string;
  countryEn: string;
  latitude: number;
  longitude: number;
  timezone: string;
};

export const PRESETS: Preset[] = [
  { id: "riyadh", nameAr: "الرياض", nameEn: "Riyadh", countryAr: "السعودية", countryEn: "Saudi Arabia", latitude: 24.7136, longitude: 46.6753, timezone: "Asia/Riyadh" },
  { id: "jeddah", nameAr: "جدة", nameEn: "Jeddah", countryAr: "السعودية", countryEn: "Saudi Arabia", latitude: 21.5433, longitude: 39.1728, timezone: "Asia/Riyadh" },
  { id: "makkah", nameAr: "مكة", nameEn: "Makkah", countryAr: "السعودية", countryEn: "Saudi Arabia", latitude: 21.3891, longitude: 39.8579, timezone: "Asia/Riyadh" },
  { id: "dammam", nameAr: "الدمام", nameEn: "Dammam", countryAr: "السعودية", countryEn: "Saudi Arabia", latitude: 26.4207, longitude: 50.0888, timezone: "Asia/Riyadh" },
  { id: "dubai", nameAr: "دبي", nameEn: "Dubai", countryAr: "الإمارات", countryEn: "UAE", latitude: 25.2048, longitude: 55.2708, timezone: "Asia/Dubai" },
  { id: "doha", nameAr: "الدوحة", nameEn: "Doha", countryAr: "قطر", countryEn: "Qatar", latitude: 25.2854, longitude: 51.531, timezone: "Asia/Qatar" },
  { id: "kuwait", nameAr: "الكويت", nameEn: "Kuwait", countryAr: "الكويت", countryEn: "Kuwait", latitude: 29.3759, longitude: 47.9774, timezone: "Asia/Kuwait" },
  { id: "cairo", nameAr: "القاهرة", nameEn: "Cairo", countryAr: "مصر", countryEn: "Egypt", latitude: 30.0444, longitude: 31.2357, timezone: "Africa/Cairo" },
  { id: "amman", nameAr: "عمّان", nameEn: "Amman", countryAr: "الأردن", countryEn: "Jordan", latitude: 31.9454, longitude: 35.9284, timezone: "Asia/Amman" },
  { id: "beirut", nameAr: "بيروت", nameEn: "Beirut", countryAr: "لبنان", countryEn: "Lebanon", latitude: 33.8938, longitude: 35.5018, timezone: "Asia/Beirut" },
  { id: "istanbul", nameAr: "إسطنبول", nameEn: "Istanbul", countryAr: "تركيا", countryEn: "Türkiye", latitude: 41.0082, longitude: 28.9784, timezone: "Europe/Istanbul" },
  { id: "london", nameAr: "لندن", nameEn: "London", countryAr: "بريطانيا", countryEn: "UK", latitude: 51.5074, longitude: -0.1278, timezone: "Europe/London" },
  { id: "paris", nameAr: "باريس", nameEn: "Paris", countryAr: "فرنسا", countryEn: "France", latitude: 48.8566, longitude: 2.3522, timezone: "Europe/Paris" },
  { id: "newyork", nameAr: "نيويورك", nameEn: "New York", countryAr: "أمريكا", countryEn: "USA", latitude: 40.7128, longitude: -74.006, timezone: "America/New_York" },
  { id: "tokyo", nameAr: "طوكيو", nameEn: "Tokyo", countryAr: "اليابان", countryEn: "Japan", latitude: 35.6762, longitude: 139.6503, timezone: "Asia/Tokyo" },
];

export function toPlace(preset: Preset, lang: Lang): Place {
  return {
    id: preset.id,
    name: lang === "ar" ? preset.nameAr : preset.nameEn,
    country: lang === "ar" ? preset.countryAr : preset.countryEn,
    latitude: preset.latitude,
    longitude: preset.longitude,
    timezone: preset.timezone,
  };
}

export const DEFAULT_PLACE = toPlace(PRESETS[0]!, "ar");

export function placeTitle(place: Place, lang: Lang) {
  const preset = PRESETS.find((item) => item.id === place.id);
  if (!preset) return place.name;
  return lang === "ar" ? preset.nameAr : preset.nameEn;
}

export function placeCountry(place: Place, lang: Lang) {
  const preset = PRESETS.find((item) => item.id === place.id);
  if (!preset) return place.country;
  return lang === "ar" ? preset.countryAr : preset.countryEn;
}
