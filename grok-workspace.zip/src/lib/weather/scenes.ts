export type SceneId =
  | "pending"
  | "clear-day"
  | "clear-night"
  | "partly-day"
  | "partly-night"
  | "cloudy-day"
  | "cloudy-night"
  | "rain-day"
  | "rain-night"
  | "storm"
  | "snow-day"
  | "snow-night"
  | "fog"
  | "wind";

export type DiscKind = "sun" | "cloud" | "rain" | "storm" | "snow" | "fog" | "night";

export const SCENE_META: { id: SceneId; ar: string; en: string }[] = [
  { id: "clear-day", ar: "صحو", en: "Clear" },
  { id: "partly-day", ar: "جزئي", en: "Partly" },
  { id: "cloudy-day", ar: "غائم", en: "Cloudy" },
  { id: "rain-day", ar: "مطر", en: "Rain" },
  { id: "storm", ar: "رعد", en: "Storm" },
  { id: "snow-day", ar: "ثلج", en: "Snow" },
  { id: "fog", ar: "ضباب", en: "Fog" },
  { id: "wind", ar: "ريح", en: "Wind" },
  { id: "clear-night", ar: "ليل", en: "Night" },
  { id: "rain-night", ar: "ليل ممطر", en: "Night rain" },
];

export function isSnowCode(code: number) {
  return (code >= 71 && code <= 77) || code === 85 || code === 86;
}

export function isRainCode(code: number) {
  return (code >= 51 && code <= 67) || (code >= 80 && code <= 82);
}

export function sceneFromWeather(code: number, isDay: boolean, wind: number): SceneId {
  const night = !isDay;
  if (code >= 95) return "storm";
  if (code === 45 || code === 48) return "fog";
  if (isSnowCode(code)) return night ? "snow-night" : "snow-day";
  if (isRainCode(code)) return night ? "rain-night" : "rain-day";
  if (code === 3) return night ? "cloudy-night" : "cloudy-day";
  if (code === 1 || code === 2) {
    if (!night && wind >= 40) return "wind";
    return night ? "partly-night" : "partly-day";
  }
  if (!night && wind >= 42) return "wind";
  return night ? "clear-night" : "clear-day";
}

export function guessScene(hour: number): SceneId {
  if (hour >= 5.8 && hour < 18) return "partly-day";
  return "clear-night";
}

export function visualHour(scene: SceneId, hour: number) {
  const night = scene.endsWith("night");
  if (night) {
    if (hour <= 5.6 || hour >= 17.4) return hour;
    return 22;
  }
  if (scene === "storm" || scene === "fog" || scene === "pending") return hour;
  if (hour > 6 && hour < 18.4) return hour;
  return 11;
}

export function discKind(code: number, isDay: boolean): DiscKind {
  if (code >= 95) return "storm";
  if (code === 45 || code === 48) return "fog";
  if (isSnowCode(code)) return "snow";
  if (isRainCode(code)) return "rain";
  if (!isDay && code <= 1) return "night";
  if (code >= 2) return "cloud";
  return "sun";
}
