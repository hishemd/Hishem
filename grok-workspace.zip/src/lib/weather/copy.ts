import type { Lang } from "@/lib/weather/types";

const CONDITIONS: Record<number, { ar: string; en: string }> = {
  0: { ar: "صحو", en: "Clear" },
  1: { ar: "صافٍ غالباً", en: "Mainly clear" },
  2: { ar: "غائم جزئياً", en: "Partly cloudy" },
  3: { ar: "غائم", en: "Overcast" },
  45: { ar: "ضباب", en: "Fog" },
  48: { ar: "ضباب متجمد", en: "Rime fog" },
  51: { ar: "رذاذ خفيف", en: "Light drizzle" },
  53: { ar: "رذاذ", en: "Drizzle" },
  55: { ar: "رذاذ كثيف", en: "Dense drizzle" },
  56: { ar: "رذاذ متجمد", en: "Freezing drizzle" },
  57: { ar: "رذاذ متجمد كثيف", en: "Dense freezing drizzle" },
  61: { ar: "مطر خفيف", en: "Light rain" },
  63: { ar: "مطر", en: "Rain" },
  65: { ar: "مطر غزير", en: "Heavy rain" },
  66: { ar: "مطر متجمد", en: "Freezing rain" },
  67: { ar: "مطر متجمد غزير", en: "Heavy freezing rain" },
  71: { ar: "ثلج خفيف", en: "Light snow" },
  73: { ar: "ثلج", en: "Snow" },
  75: { ar: "ثلج كثيف", en: "Heavy snow" },
  77: { ar: "حبات ثلج", en: "Snow grains" },
  80: { ar: "زخات خفيفة", en: "Light showers" },
  81: { ar: "زخات", en: "Showers" },
  82: { ar: "زخات قوية", en: "Heavy showers" },
  85: { ar: "زخات ثلج", en: "Snow showers" },
  86: { ar: "زخات ثلج كثيفة", en: "Heavy snow showers" },
  95: { ar: "عاصفة رعدية", en: "Thunderstorm" },
  96: { ar: "عاصفة وبَرَد", en: "Thunderstorm hail" },
  99: { ar: "عاصفة شديدة", en: "Severe thunderstorm" },
};

export function conditionText(code: number, lang: Lang) {
  const row = CONDITIONS[code];
  if (row) return row[lang];
  if (code >= 95) return lang === "ar" ? "عاصفة رعدية" : "Thunderstorm";
  if (code >= 71) return lang === "ar" ? "ثلج" : "Snow";
  if (code >= 51) return lang === "ar" ? "مطر" : "Rain";
  return lang === "ar" ? "متقلب" : "Mixed";
}

export type Copy = {
  feels: string;
  humidity: string;
  wind: string;
  uv: string;
  hourly: string;
  daily: string;
  search: string;
  searchPh: string;
  locate: string;
  cities: string;
  recent: string;
  noResults: string;
  close: string;
  error: string;
  retry: string;
  loading: string;
  previewing: string;
  scenes: string;
  now: string;
  tour: string;
  tourStop: string;
  toC: string;
  toF: string;
  switchLang: string;
  geoDenied: string;
  geoFailed: string;
  geoWorking: string;
  myLocation: string;
  openCity: string;
};

const ar: Copy = {
  feels: "الإحساس",
  humidity: "الرطوبة",
  wind: "الرياح",
  uv: "الأشعة",
  hourly: "الساعات القادمة",
  daily: "سبعة أيام",
  search: "ابحث عن مدينة",
  searchPh: "اسم المدينة…",
  locate: "موقعي",
  cities: "مدن",
  recent: "الأخيرة",
  noResults: "لا توجد نتائج",
  close: "إغلاق",
  error: "تعذر جلب الطقس",
  retry: "إعادة المحاولة",
  loading: "يجلب السماء…",
  previewing: "معاينة المشهد",
  scenes: "مشاهد الطقس",
  now: "الآن",
  tour: "جولة المشاهد",
  tourStop: "إيقاف الجولة",
  toC: "التبديل إلى المئوية",
  toF: "التبديل إلى الفهرنهايت",
  switchLang: "Switch to English",
  geoDenied: "لم يُسمح بالوصول إلى الموقع",
  geoFailed: "تعذر تحديد المدينة",
  geoWorking: "يجري تحديد موقعك…",
  myLocation: "موقعي",
  openCity: "تغيير المدينة",
};

const en: Copy = {
  feels: "Feels",
  humidity: "Humidity",
  wind: "Wind",
  uv: "UV",
  hourly: "Next hours",
  daily: "Seven days",
  search: "Search for a city",
  searchPh: "City name…",
  locate: "My location",
  cities: "Cities",
  recent: "Recent",
  noResults: "No matches",
  close: "Close",
  error: "Couldn’t load weather",
  retry: "Try again",
  loading: "Reading the sky…",
  previewing: "Scene preview",
  scenes: "Weather scenes",
  now: "Now",
  tour: "Play scenes",
  tourStop: "Stop tour",
  toC: "Switch to Celsius",
  toF: "Switch to Fahrenheit",
  switchLang: "التبديل إلى العربية",
  geoDenied: "Location permission was denied",
  geoFailed: "Couldn’t find that place",
  geoWorking: "Finding you…",
  myLocation: "My location",
  openCity: "Change city",
};

export function copyOf(lang: Lang) {
  return lang === "ar" ? ar : en;
}
