import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as CloudSnow, a as Sunset, b as CloudFog, c as SunMedium, d as Moon, f as MapPin, g as CloudSun, h as Cloud, i as Thermometer, l as Play, m as Droplets, n as Wind, o as Sunrise, p as Locate, s as Sun, t as X, u as Pause, v as CloudRain, y as CloudLightning } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bh9JrtNy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function mapGeo(result) {
	return {
		id: `${result.latitude.toFixed(2)},${result.longitude.toFixed(2)}`,
		name: result.name,
		country: result.admin1 ? `${result.country ?? ""} · ${result.admin1}` : result.country ?? "",
		latitude: result.latitude,
		longitude: result.longitude,
		timezone: result.timezone || "UTC"
	};
}
async function searchCities(query, lang, signal) {
	const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
	url.searchParams.set("name", query);
	url.searchParams.set("count", "6");
	url.searchParams.set("language", lang);
	url.searchParams.set("format", "json");
	const response = await fetch(url, { signal });
	if (!response.ok) throw new Error("search failed");
	return ((await response.json()).results ?? []).map(mapGeo);
}
async function reversePlace(latitude, longitude, lang) {
	const url = new URL("https://geocoding-api.open-meteo.com/v1/reverse");
	url.searchParams.set("latitude", String(latitude));
	url.searchParams.set("longitude", String(longitude));
	url.searchParams.set("language", lang);
	const response = await fetch(url);
	if (!response.ok) return null;
	const first = (await response.json()).results?.[0];
	return first ? mapGeo(first) : null;
}
async function fetchForecast(latitude, longitude, signal) {
	const url = new URL("https://api.open-meteo.com/v1/forecast");
	url.searchParams.set("latitude", String(latitude));
	url.searchParams.set("longitude", String(longitude));
	url.searchParams.set("current", "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m");
	url.searchParams.set("hourly", "temperature_2m,weather_code,precipitation_probability,is_day");
	url.searchParams.set("daily", "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max");
	url.searchParams.set("timezone", "auto");
	url.searchParams.set("forecast_days", "7");
	url.searchParams.set("wind_speed_unit", "kmh");
	const response = await fetch(url, { signal });
	if (!response.ok) throw new Error("forecast failed");
	const data = await response.json();
	if (!data.current || !data.hourly || !data.daily) throw new Error("forecast failed");
	const current = data.current;
	const hourly = data.hourly;
	const daily = data.daily;
	const stamp = current.time.slice(0, 13);
	let start = hourly.time.findIndex((time) => time.slice(0, 13) >= stamp);
	if (start < 0) start = 0;
	const hours = [];
	for (let index = start; index < Math.min(hourly.time.length, start + 24); index += 1) hours.push({
		time: hourly.time[index] ?? "",
		temp: hourly.temperature_2m[index] ?? 0,
		code: hourly.weather_code[index] ?? 0,
		pop: hourly.precipitation_probability[index] ?? 0,
		isDay: Boolean(hourly.is_day[index])
	});
	return {
		timezone: data.timezone || "UTC",
		current: {
			temperature: current.temperature_2m,
			apparent: current.apparent_temperature,
			humidity: current.relative_humidity_2m,
			code: current.weather_code,
			isDay: Boolean(current.is_day),
			wind: current.wind_speed_10m
		},
		hourly: hours,
		daily: daily.time.map((date, index) => ({
			date,
			code: daily.weather_code[index] ?? 0,
			max: daily.temperature_2m_max[index] ?? 0,
			min: daily.temperature_2m_min[index] ?? 0,
			pop: daily.precipitation_probability_max?.[index] ?? 0,
			uv: daily.uv_index_max?.[index] ?? null,
			sunrise: daily.sunrise[index] ?? "",
			sunset: daily.sunset[index] ?? ""
		}))
	};
}
var CONDITIONS = {
	0: {
		ar: "صحو",
		en: "Clear"
	},
	1: {
		ar: "صافٍ غالباً",
		en: "Mainly clear"
	},
	2: {
		ar: "غائم جزئياً",
		en: "Partly cloudy"
	},
	3: {
		ar: "غائم",
		en: "Overcast"
	},
	45: {
		ar: "ضباب",
		en: "Fog"
	},
	48: {
		ar: "ضباب متجمد",
		en: "Rime fog"
	},
	51: {
		ar: "رذاذ خفيف",
		en: "Light drizzle"
	},
	53: {
		ar: "رذاذ",
		en: "Drizzle"
	},
	55: {
		ar: "رذاذ كثيف",
		en: "Dense drizzle"
	},
	56: {
		ar: "رذاذ متجمد",
		en: "Freezing drizzle"
	},
	57: {
		ar: "رذاذ متجمد كثيف",
		en: "Dense freezing drizzle"
	},
	61: {
		ar: "مطر خفيف",
		en: "Light rain"
	},
	63: {
		ar: "مطر",
		en: "Rain"
	},
	65: {
		ar: "مطر غزير",
		en: "Heavy rain"
	},
	66: {
		ar: "مطر متجمد",
		en: "Freezing rain"
	},
	67: {
		ar: "مطر متجمد غزير",
		en: "Heavy freezing rain"
	},
	71: {
		ar: "ثلج خفيف",
		en: "Light snow"
	},
	73: {
		ar: "ثلج",
		en: "Snow"
	},
	75: {
		ar: "ثلج كثيف",
		en: "Heavy snow"
	},
	77: {
		ar: "حبات ثلج",
		en: "Snow grains"
	},
	80: {
		ar: "زخات خفيفة",
		en: "Light showers"
	},
	81: {
		ar: "زخات",
		en: "Showers"
	},
	82: {
		ar: "زخات قوية",
		en: "Heavy showers"
	},
	85: {
		ar: "زخات ثلج",
		en: "Snow showers"
	},
	86: {
		ar: "زخات ثلج كثيفة",
		en: "Heavy snow showers"
	},
	95: {
		ar: "عاصفة رعدية",
		en: "Thunderstorm"
	},
	96: {
		ar: "عاصفة وبَرَد",
		en: "Thunderstorm hail"
	},
	99: {
		ar: "عاصفة شديدة",
		en: "Severe thunderstorm"
	}
};
function conditionText(code, lang) {
	const row = CONDITIONS[code];
	if (row) return row[lang];
	if (code >= 95) return lang === "ar" ? "عاصفة رعدية" : "Thunderstorm";
	if (code >= 71) return lang === "ar" ? "ثلج" : "Snow";
	if (code >= 51) return lang === "ar" ? "مطر" : "Rain";
	return lang === "ar" ? "متقلب" : "Mixed";
}
var ar = {
	feels: "الإحساس",
	humidity: "الرطوبة",
	wind: "الرياح",
	uv: "الأشعة",
	hourly: "الساعات القادمة",
	daily: "سبعة أيام",
	search: "ابحث عن مدينة",
	searchPh: "اسم المدينة…",
	locate: "موقعي",
	cities: "مدن",
	recent: "الأخيرة",
	noResults: "لا توجد نتائج",
	close: "إغلاق",
	error: "تعذر جلب الطقس",
	retry: "إعادة المحاولة",
	loading: "يجلب السماء…",
	previewing: "معاينة المشهد",
	scenes: "مشاهد الطقس",
	now: "الآن",
	tour: "جولة المشاهد",
	tourStop: "إيقاف الجولة",
	toC: "التبديل إلى المئوية",
	toF: "التبديل إلى الفهرنهايت",
	switchLang: "Switch to English",
	geoDenied: "لم يُسمح بالوصول إلى الموقع",
	geoFailed: "تعذر تحديد المدينة",
	geoWorking: "يجري تحديد موقعك…",
	myLocation: "موقعي",
	openCity: "تغيير المدينة"
};
var en = {
	feels: "Feels",
	humidity: "Humidity",
	wind: "Wind",
	uv: "UV",
	hourly: "Next hours",
	daily: "Seven days",
	search: "Search for a city",
	searchPh: "City name…",
	locate: "My location",
	cities: "Cities",
	recent: "Recent",
	noResults: "No matches",
	close: "Close",
	error: "Couldn’t load weather",
	retry: "Try again",
	loading: "Reading the sky…",
	previewing: "Scene preview",
	scenes: "Weather scenes",
	now: "Now",
	tour: "Play scenes",
	tourStop: "Stop tour",
	toC: "Switch to Celsius",
	toF: "Switch to Fahrenheit",
	switchLang: "التبديل إلى العربية",
	geoDenied: "Location permission was denied",
	geoFailed: "Couldn’t find that place",
	geoWorking: "Finding you…",
	myLocation: "My location",
	openCity: "Change city"
};
function copyOf(lang) {
	return lang === "ar" ? ar : en;
}
function locale(lang) {
	return lang === "ar" ? "ar-SA-u-nu-latn" : "en-US";
}
function zonedHour(date, timeZone) {
	const parts = new Intl.DateTimeFormat("en-US", {
		timeZone,
		hour: "2-digit",
		minute: "2-digit",
		hourCycle: "h23"
	}).formatToParts(date);
	const pick = (type) => Number(parts.find((part) => part.type === type)?.value ?? "0");
	let hour = pick("hour");
	if (hour === 24) hour = 0;
	const minute = pick("minute");
	return {
		hour,
		minute,
		hourFloat: hour + minute / 60
	};
}
function clockFace(date, timeZone, lang) {
	const zoned = zonedHour(date, timeZone);
	const period = zoned.hour < 12 ? lang === "ar" ? "ص" : "AM" : lang === "ar" ? "م" : "PM";
	const h12 = zoned.hour % 12 || 12;
	return {
		hours: String(h12).padStart(2, "0"),
		minutes: String(zoned.minute).padStart(2, "0"),
		period,
		hourFloat: zoned.hourFloat
	};
}
function dateLabel(date, timeZone, lang) {
	return new Intl.DateTimeFormat(locale(lang), {
		weekday: "short",
		day: "numeric",
		month: "short",
		timeZone
	}).format(date);
}
function dayName(iso, index, lang) {
	if (index === 0) return lang === "ar" ? "اليوم" : "Today";
	if (index === 1) return lang === "ar" ? "غداً" : "Tomorrow";
	const [year, month, day] = iso.split("-").map(Number);
	const utc = new Date(Date.UTC(year ?? 2026, (month ?? 1) - 1, day ?? 1, 12));
	return new Intl.DateTimeFormat(locale(lang), {
		weekday: "short",
		timeZone: "UTC"
	}).format(utc);
}
function hourLabel(iso, lang) {
	const hour = Number(iso.slice(11, 13));
	return `${hour % 12 || 12} ${hour < 12 ? lang === "ar" ? "ص" : "AM" : lang === "ar" ? "م" : "PM"}`;
}
function clockFromIso(iso, lang) {
	const hour = Number(iso.slice(11, 13));
	const minute = iso.slice(14, 16);
	return `${hour % 12 || 12}:${minute} ${hour < 12 ? lang === "ar" ? "ص" : "AM" : lang === "ar" ? "م" : "PM"}`;
}
function tempOf(celsius, unit) {
	const value = unit === "f" ? celsius * 9 / 5 + 32 : celsius;
	return Math.round(value);
}
function windText(kmh, unit, lang) {
	if (unit === "f") return `${Math.round(kmh * .621371)} ${lang === "ar" ? "ميل/س" : "mph"}`;
	return `${Math.round(kmh)} ${lang === "ar" ? "كم/س" : "km/h"}`;
}
function uvText(uv) {
	if (uv == null || Number.isNaN(uv)) return "—";
	return uv >= 10 ? String(Math.round(uv)) : uv.toFixed(1);
}
var PRESETS = [
	{
		id: "riyadh",
		nameAr: "الرياض",
		nameEn: "Riyadh",
		countryAr: "السعودية",
		countryEn: "Saudi Arabia",
		latitude: 24.7136,
		longitude: 46.6753,
		timezone: "Asia/Riyadh"
	},
	{
		id: "jeddah",
		nameAr: "جدة",
		nameEn: "Jeddah",
		countryAr: "السعودية",
		countryEn: "Saudi Arabia",
		latitude: 21.5433,
		longitude: 39.1728,
		timezone: "Asia/Riyadh"
	},
	{
		id: "makkah",
		nameAr: "مكة",
		nameEn: "Makkah",
		countryAr: "السعودية",
		countryEn: "Saudi Arabia",
		latitude: 21.3891,
		longitude: 39.8579,
		timezone: "Asia/Riyadh"
	},
	{
		id: "dammam",
		nameAr: "الدمام",
		nameEn: "Dammam",
		countryAr: "السعودية",
		countryEn: "Saudi Arabia",
		latitude: 26.4207,
		longitude: 50.0888,
		timezone: "Asia/Riyadh"
	},
	{
		id: "dubai",
		nameAr: "دبي",
		nameEn: "Dubai",
		countryAr: "الإمارات",
		countryEn: "UAE",
		latitude: 25.2048,
		longitude: 55.2708,
		timezone: "Asia/Dubai"
	},
	{
		id: "doha",
		nameAr: "الدوحة",
		nameEn: "Doha",
		countryAr: "قطر",
		countryEn: "Qatar",
		latitude: 25.2854,
		longitude: 51.531,
		timezone: "Asia/Qatar"
	},
	{
		id: "kuwait",
		nameAr: "الكويت",
		nameEn: "Kuwait",
		countryAr: "الكويت",
		countryEn: "Kuwait",
		latitude: 29.3759,
		longitude: 47.9774,
		timezone: "Asia/Kuwait"
	},
	{
		id: "cairo",
		nameAr: "القاهرة",
		nameEn: "Cairo",
		countryAr: "مصر",
		countryEn: "Egypt",
		latitude: 30.0444,
		longitude: 31.2357,
		timezone: "Africa/Cairo"
	},
	{
		id: "amman",
		nameAr: "عمّان",
		nameEn: "Amman",
		countryAr: "الأردن",
		countryEn: "Jordan",
		latitude: 31.9454,
		longitude: 35.9284,
		timezone: "Asia/Amman"
	},
	{
		id: "beirut",
		nameAr: "بيروت",
		nameEn: "Beirut",
		countryAr: "لبنان",
		countryEn: "Lebanon",
		latitude: 33.8938,
		longitude: 35.5018,
		timezone: "Asia/Beirut"
	},
	{
		id: "istanbul",
		nameAr: "إسطنبول",
		nameEn: "Istanbul",
		countryAr: "تركيا",
		countryEn: "Türkiye",
		latitude: 41.0082,
		longitude: 28.9784,
		timezone: "Europe/Istanbul"
	},
	{
		id: "london",
		nameAr: "لندن",
		nameEn: "London",
		countryAr: "بريطانيا",
		countryEn: "UK",
		latitude: 51.5074,
		longitude: -.1278,
		timezone: "Europe/London"
	},
	{
		id: "paris",
		nameAr: "باريس",
		nameEn: "Paris",
		countryAr: "فرنسا",
		countryEn: "France",
		latitude: 48.8566,
		longitude: 2.3522,
		timezone: "Europe/Paris"
	},
	{
		id: "newyork",
		nameAr: "نيويورك",
		nameEn: "New York",
		countryAr: "أمريكا",
		countryEn: "USA",
		latitude: 40.7128,
		longitude: -74.006,
		timezone: "America/New_York"
	},
	{
		id: "tokyo",
		nameAr: "طوكيو",
		nameEn: "Tokyo",
		countryAr: "اليابان",
		countryEn: "Japan",
		latitude: 35.6762,
		longitude: 139.6503,
		timezone: "Asia/Tokyo"
	}
];
function toPlace(preset, lang) {
	return {
		id: preset.id,
		name: lang === "ar" ? preset.nameAr : preset.nameEn,
		country: lang === "ar" ? preset.countryAr : preset.countryEn,
		latitude: preset.latitude,
		longitude: preset.longitude,
		timezone: preset.timezone
	};
}
var DEFAULT_PLACE = toPlace(PRESETS[0], "ar");
function placeTitle(place, lang) {
	const preset = PRESETS.find((item) => item.id === place.id);
	if (!preset) return place.name;
	return lang === "ar" ? preset.nameAr : preset.nameEn;
}
function placeCountry(place, lang) {
	const preset = PRESETS.find((item) => item.id === place.id);
	if (!preset) return place.country;
	return lang === "ar" ? preset.countryAr : preset.countryEn;
}
var SCENE_META = [
	{
		id: "clear-day",
		ar: "صحو",
		en: "Clear"
	},
	{
		id: "partly-day",
		ar: "جزئي",
		en: "Partly"
	},
	{
		id: "cloudy-day",
		ar: "غائم",
		en: "Cloudy"
	},
	{
		id: "rain-day",
		ar: "مطر",
		en: "Rain"
	},
	{
		id: "storm",
		ar: "رعد",
		en: "Storm"
	},
	{
		id: "snow-day",
		ar: "ثلج",
		en: "Snow"
	},
	{
		id: "fog",
		ar: "ضباب",
		en: "Fog"
	},
	{
		id: "wind",
		ar: "ريح",
		en: "Wind"
	},
	{
		id: "clear-night",
		ar: "ليل",
		en: "Night"
	},
	{
		id: "rain-night",
		ar: "ليل ممطر",
		en: "Night rain"
	}
];
function isSnowCode(code) {
	return code >= 71 && code <= 77 || code === 85 || code === 86;
}
function isRainCode(code) {
	return code >= 51 && code <= 67 || code >= 80 && code <= 82;
}
function sceneFromWeather(code, isDay, wind) {
	const night = !isDay;
	if (code >= 95) return "storm";
	if (code === 45 || code === 48) return "fog";
	if (isSnowCode(code)) return night ? "snow-night" : "snow-day";
	if (isRainCode(code)) return night ? "rain-night" : "rain-day";
	if (code === 3) return night ? "cloudy-night" : "cloudy-day";
	if (code === 1 || code === 2) {
		if (!night && wind >= 40) return "wind";
		return night ? "partly-night" : "partly-day";
	}
	if (!night && wind >= 42) return "wind";
	return night ? "clear-night" : "clear-day";
}
function guessScene(hour) {
	if (hour >= 5.8 && hour < 18) return "partly-day";
	return "clear-night";
}
function visualHour(scene, hour) {
	if (scene.endsWith("night")) {
		if (hour <= 5.6 || hour >= 17.4) return hour;
		return 22;
	}
	if (scene === "storm" || scene === "fog") return hour;
	if (hour > 6 && hour < 18.4) return hour;
	return 11;
}
function discKind(code, isDay) {
	if (code >= 95) return "storm";
	if (code === 45 || code === 48) return "fog";
	if (isSnowCode(code)) return "snow";
	if (isRainCode(code)) return "rain";
	if (!isDay && code <= 1) return "night";
	if (code >= 2) return "cloud";
	return "sun";
}
var KEY = "halo-weather-v1";
function isPlace(value) {
	if (!value || typeof value !== "object") return false;
	const place = value;
	return typeof place.id === "string" && typeof place.name === "string" && typeof place.country === "string" && typeof place.latitude === "number" && typeof place.longitude === "number" && typeof place.timezone === "string";
}
var useHalo = create((set) => ({
	lang: "ar",
	unit: "c",
	place: DEFAULT_PLACE,
	recent: [],
	setLang: (lang) => set({ lang }),
	setUnit: (unit) => set({ unit }),
	setPlace: (place) => set((state) => ({
		place,
		recent: [place, ...state.recent.filter((item) => item.id !== place.id)].slice(0, 5)
	}))
}));
function usePersistHalo() {
	(0, import_react.useEffect)(() => {
		try {
			const raw = localStorage.getItem(KEY);
			if (raw) {
				const parsed = JSON.parse(raw);
				const place = isPlace(parsed.place) ? parsed.place : null;
				if (place) {
					const recent = Array.isArray(parsed.recent) ? parsed.recent.filter(isPlace).slice(0, 5) : [];
					useHalo.setState({
						lang: parsed.lang === "en" ? "en" : "ar",
						unit: parsed.unit === "f" ? "f" : "c",
						place,
						recent
					});
				}
			}
		} catch {}
		return useHalo.subscribe((state) => {
			localStorage.setItem(KEY, JSON.stringify({
				lang: state.lang,
				unit: state.unit,
				place: state.place,
				recent: state.recent
			}));
		});
	}, []);
}
function prefersReduced() {
	return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
function FlipCard({ value, period }) {
	const shownRef = (0, import_react.useRef)("88");
	const seq = (0, import_react.useRef)(0);
	const [shown, setShown] = (0, import_react.useState)("88");
	const [flop, setFlop] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (value === shownRef.current) return;
		const from = shownRef.current;
		if (prefersReduced()) {
			shownRef.current = value;
			setShown(value);
			setFlop(null);
			return;
		}
		const key = ++seq.current;
		setFlop({
			from,
			to: value,
			key
		});
		const timer = window.setTimeout(() => {
			shownRef.current = value;
			setShown(value);
			setFlop(null);
		}, 520);
		return () => window.clearTimeout(timer);
	}, [value]);
	const top = flop ? flop.to : shown;
	const bottom = flop ? flop.from : shown;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flip-card",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "half top",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "num",
					children: top
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "half bottom",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "num",
					children: bottom
				})
			}),
			flop ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "leaf top play",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "num",
					children: flop.from
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "shade" })]
			}, `${flop.key}-a`), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "leaf bottom play",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "num",
					children: flop.to
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "shade" })]
			}, `${flop.key}-b`)] }) : null,
			period ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "period",
				children: period
			}) : null
		]
	});
}
function FlipClock({ hours, minutes, period }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flip-row",
		dir: "ltr",
		role: "group",
		"aria-label": `${hours}:${minutes} ${period}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlipCard, { value: hours }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlipCard, {
			value: minutes,
			period
		})]
	});
}
function ClockPlaceholder() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flip-row",
		"aria-hidden": "true",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flip-card" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flip-card" })]
	});
}
function WeatherGlyph({ code, isDay, className }) {
	const Icon = code >= 95 ? CloudLightning : code === 45 || code === 48 ? CloudFog : isSnowCode(code) ? CloudSnow : isRainCode(code) ? CloudRain : code === 3 ? Cloud : code === 1 || code === 2 ? isDay ? CloudSun : Cloud : isDay ? Sun : Moon;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
		className,
		strokeWidth: 1.7,
		"aria-hidden": "true"
	});
}
function rnd(index, salt) {
	const value = Math.sin(index * 127.1 + salt * 311.7) * 43758.5453;
	return value - Math.floor(value);
}
function sunPoint(hour) {
	const t = Math.min(1, Math.max(0, (hour - 6.1) / 12.2));
	return {
		left: `${(10 + 80 * t).toFixed(1)}%`,
		top: `${(46 - Math.sin(t * Math.PI) * 30).toFixed(1)}%`
	};
}
function moonPoint(hour) {
	const shifted = hour < 16 ? hour + 24 : hour;
	const t = Math.min(1, Math.max(0, (shifted - 18) / 12));
	return {
		left: `${(14 + 70 * t).toFixed(1)}%`,
		top: `${(32 - Math.sin(t * Math.PI) * 14).toFixed(1)}%`
	};
}
function makeBuildings() {
	const buildings = [];
	let x = 0;
	for (let index = 0; x < 1440 && index < 42; index += 1) {
		const w = 36 + Math.floor(rnd(index, 1) * 52);
		const h = 48 + Math.floor(rnd(index, 2) * 168);
		buildings.push({
			x,
			w,
			h
		});
		x += w - 1;
	}
	return buildings;
}
var BUILDINGS = makeBuildings();
var WINDOWS = BUILDINGS.flatMap((building, index) => {
	const count = 2 + Math.floor(rnd(index, 4) * 5);
	return Array.from({ length: count }, (_, key) => ({
		x: building.x + 6 + rnd(index * 19 + key, 5) * Math.max(6, building.w - 16),
		y: 400 - building.h + 10 + rnd(index * 19 + key, 6) * Math.max(6, building.h - 22),
		id: `${index}-${key}`
	}));
});
var FAR_SPOTS = [
	4,
	17,
	30,
	43
];
var NEAR_SPOTS = [
	8,
	22,
	36,
	47
];
function CloudBand({ variant }) {
	const spots = variant === "far" ? FAR_SPOTS : NEAR_SPOTS;
	const all = [...spots, ...spots.map((spot) => spot + 50)];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `cloud-band ${variant}`,
		children: all.map((left, index) => {
			const seed = index % spots.length;
			const width = (variant === "far" ? 22 : 30) + rnd(seed, 3) * 16;
			const height = (variant === "far" ? 11 : 14) + rnd(seed, 4) * 7;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
				className: "cloud",
				style: {
					left: `${left}%`,
					top: `${6 + rnd(seed, variant === "far" ? 2 : 7) * 48}%`,
					width: `${width}vw`,
					height: `${height}vw`
				}
			}, `${variant}-${left}`);
		})
	});
}
function WeatherScene({ scene, hour }) {
	const sun = sunPoint(hour);
	const moon = moonPoint(hour);
	const sunStyle = {
		left: sun.left,
		top: sun.top
	};
	const moonStyle = {
		left: moon.left,
		top: moon.top
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `sky scene-${scene}`,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sky-fill" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "stars",
				children: Array.from({ length: 42 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
					className: rnd(index, 9) > .86 ? "star big" : "star",
					style: {
						left: `${rnd(index, 1) * 100}%`,
						top: `${rnd(index, 2) * 58}%`,
						animationDelay: `${-rnd(index, 3) * 4}s`
					}
				}, index))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "horizon-glow",
				style: { left: sun.left }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sun",
				style: sunStyle,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sun-glow" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rays" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "disc" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "moon",
				style: moonStyle,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "moon-glow" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "moon-disc",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "crater c1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "crater c2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "crater c3" })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudBand, { variant: "far" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudBand, { variant: "near" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				className: "hills back",
				viewBox: "0 0 1440 360",
				preserveAspectRatio: "none",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					className: "hill far",
					d: "M0 158 C140 96 260 188 400 132 C560 68 700 176 880 124 C1060 70 1220 160 1440 108 L1440 360 L0 360 Z"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					className: "hill mid",
					d: "M0 206 C170 156 320 236 500 186 C720 128 880 228 1100 176 C1260 146 1360 196 1440 168 L1440 360 L0 360 Z"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
				className: "skyline",
				viewBox: "0 0 1440 400",
				preserveAspectRatio: "xMidYMax slice",
				children: [BUILDINGS.map((building) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					className: "bldg",
					x: building.x,
					y: 400 - building.h,
					width: building.w - 3,
					height: building.h
				}, `${building.x}`)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
					className: "wins",
					children: WINDOWS.map((window) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
						className: "win",
						x: window.x,
						y: window.y,
						width: "3.2",
						height: "4.2",
						rx: "0.4"
					}, window.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				className: "hills front",
				viewBox: "0 0 1440 360",
				preserveAspectRatio: "none",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					className: "hill near",
					d: "M0 236 C210 196 380 286 580 238 C820 184 1020 276 1240 226 C1340 206 1390 236 1440 214 L1440 360 L0 360 Z"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rain l1" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rain l2" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "rain l3" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "splashes" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "snow",
				children: Array.from({ length: 34 }, (_, index) => {
					const size = 2 + rnd(index, 4) * 5;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
						className: "flake",
						style: {
							left: `${rnd(index, 1) * 100}%`,
							width: size,
							height: size,
							animationDuration: `${8 + rnd(index, 2) * 10}s`,
							animationDelay: `${-rnd(index, 3) * 14}s`,
							opacity: .45 + rnd(index, 5) * .55
						}
					}, index);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "leaf-field",
				children: Array.from({ length: 14 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
					className: `leaf tone-${index % 4}`,
					style: {
						top: `${8 + rnd(index, 2) * 62}%`,
						animationDuration: `${6 + rnd(index, 3) * 7}s`,
						animationDelay: `${-rnd(index, 4) * 9}s`
					}
				}, index))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "fog f1" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "fog f2" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				className: "bolt b1",
				viewBox: "0 0 80 180",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", { points: "46,0 20,74 38,74 12,168 64,66 42,66 70,0" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
				className: "bolt b2",
				viewBox: "0 0 80 180",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polygon", { points: "40,0 16,80 34,80 18,170 66,72 44,72 68,0" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flash" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "glass",
				children: Array.from({ length: 12 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", {
					className: "gdrop",
					style: {
						left: `${8 + rnd(index, 1) * 84}%`,
						top: `${12 + rnd(index, 2) * 70}%`,
						width: 5 + rnd(index, 3) * 9,
						height: 7 + rnd(index, 4) * 12
					}
				}, index))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "wiper" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "vignette" })
		]
	});
}
function SceneIcon({ id }) {
	const className = "size-5";
	switch (id) {
		case "clear-day": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className });
		case "partly-day": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudSun, { className });
		case "cloudy-day":
		case "cloudy-night": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cloud, { className });
		case "rain-day":
		case "rain-night": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudRain, { className });
		case "storm": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudLightning, { className });
		case "snow-day":
		case "snow-night": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudSnow, { className });
		case "fog": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudFog, { className });
		case "wind": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wind, { className });
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className });
	}
}
function WeatherApp() {
	usePersistHalo();
	const lang = useHalo((state) => state.lang);
	const unit = useHalo((state) => state.unit);
	const place = useHalo((state) => state.place);
	const recent = useHalo((state) => state.recent);
	const setLang = useHalo((state) => state.setLang);
	const setUnit = useHalo((state) => state.setUnit);
	const setPlace = useHalo((state) => state.setPlace);
	const copy = copyOf(lang);
	const [now, setNow] = (0, import_react.useState)(null);
	const [pack, setPack] = (0, import_react.useState)(null);
	const [errorId, setErrorId] = (0, import_react.useState)(null);
	const [nonce, setNonce] = (0, import_react.useState)(0);
	const [sheet, setSheet] = (0, import_react.useState)(false);
	const [sceneOverride, setSceneOverride] = (0, import_react.useState)(null);
	const [playing, setPlaying] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setNow(/* @__PURE__ */ new Date());
		const timer = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		return () => window.clearInterval(timer);
	}, []);
	(0, import_react.useEffect)(() => {
		document.title = `Halo · ${placeTitle(place, lang)}`;
	}, [place, lang]);
	(0, import_react.useEffect)(() => {
		const controller = new AbortController();
		let ignore = false;
		setErrorId((current) => current === place.id ? null : current);
		fetchForecast(place.latitude, place.longitude, controller.signal).then((data) => {
			if (ignore) return;
			setPack({
				id: place.id,
				data
			});
			setErrorId(null);
		}).catch((error) => {
			if (ignore) return;
			if (error instanceof Error && error.name === "AbortError") return;
			setErrorId(place.id);
		});
		return () => {
			ignore = true;
			controller.abort();
		};
	}, [
		place.id,
		place.latitude,
		place.longitude,
		nonce
	]);
	(0, import_react.useEffect)(() => {
		if (!playing) return;
		const timer = window.setInterval(() => {
			setSceneOverride((current) => {
				const ids = SCENE_META.map((item) => item.id);
				return ids[((current ? ids.indexOf(current) : -1) + 1) % ids.length] ?? "clear-day";
			});
		}, 7e3);
		return () => window.clearInterval(timer);
	}, [playing]);
	const forecast = pack?.id === place.id ? pack.data : null;
	const showError = !forecast && errorId === place.id;
	const timeZone = forecast?.timezone || place.timezone;
	const face = now ? clockFace(now, timeZone, lang) : null;
	const hour = face?.hourFloat ?? 12;
	const liveScene = forecast ? sceneFromWeather(forecast.current.code, forecast.current.isDay, forecast.current.wind) : guessScene(hour);
	const scene = sceneOverride ?? liveScene;
	const today = forecast?.daily[0];
	const weekMin = forecast ? Math.min(...forecast.daily.map((day) => day.min)) : 0;
	const weekMax = forecast ? Math.max(...forecast.daily.map((day) => day.max)) : 1;
	const span = Math.max(1, weekMax - weekMin);
	const kind = discKind(forecast?.current.code ?? 0, forecast?.current.isDay ?? (hour > 6 && hour < 18));
	function choose(next) {
		setPlace(next);
		setSheet(false);
		setPlaying(false);
		setSceneOverride(null);
	}
	function pickScene(id) {
		setPlaying(false);
		setSceneOverride(id);
	}
	function togglePlay() {
		if (playing) {
			setPlaying(false);
			return;
		}
		setSceneOverride((current) => current ?? SCENE_META[0].id);
		setPlaying(true);
	}
	const unitLabel = unit === "c" ? lang === "ar" ? "°م" : "°C" : lang === "ar" ? "°ف" : "°F";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-shell",
		dir: lang === "ar" ? "rtl" : "ltr",
		lang,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherScene, {
				scene,
				hour: visualHour(scene, hour)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "app-scroll",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "stage",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
							className: "rise",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "wordmark",
									children: "Halo"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "chip",
										"aria-label": unit === "c" ? copy.toF : copy.toC,
										onClick: () => setUnit(unit === "c" ? "f" : "c"),
										children: unitLabel
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "chip",
										"aria-label": copy.switchLang,
										onClick: () => setLang(lang === "ar" ? "en" : "ar"),
										children: lang === "ar" ? "EN" : "عربي"
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "chip mt-3 max-w-full min-w-0",
								onClick: () => setSheet(true),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
										className: "size-4 shrink-0",
										"aria-hidden": "true"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate",
										children: placeTitle(place, lang)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate text-xs text-muted",
										children: placeCountry(place, lang)
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rise flex justify-center",
							children: face ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FlipClock, {
								hours: face.hours,
								minutes: face.minutes,
								period: face.period
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockPlaceholder, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "plaque rise",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "wx-disc",
								"data-kind": showError ? "cloud" : kind,
								children: forecast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherGlyph, {
									code: forecast.current.code,
									isDay: forecast.current.isDay,
									className: "size-7"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloudSun, {
									className: "size-7",
									"aria-hidden": "true"
								})
							}), showError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col items-start gap-3 pt-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-base font-medium",
									children: copy.error
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "chip",
									onClick: () => setNonce((value) => value + 1),
									children: copy.retry
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 pt-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-lg font-medium",
											children: forecast ? conditionText(forecast.current.code, lang) : copy.loading
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted",
											children: face ? dateLabel(now ?? /* @__PURE__ */ new Date(), timeZone, lang) : " "
										}),
										sceneOverride ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-accent",
											children: copy.previewing
										}) : null
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "shrink-0 text-end",
									children: [forecast ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-display text-5xl font-light leading-none tabular-nums",
										children: [tempOf(forecast.current.temperature, unit), "°"]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "skel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted tabular-nums",
										children: today ? `${tempOf(today.max, unit)}° / ${tempOf(today.min, unit)}°` : "—"
									})]
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "grid grid-cols-2 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Thermometer, { className: "size-3.5" }),
									label: copy.feels,
									value: forecast ? `${tempOf(forecast.current.apparent, unit)}°` : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Droplets, { className: "size-3.5" }),
									label: copy.humidity,
									value: forecast ? `${Math.round(forecast.current.humidity)}%` : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wind, { className: "size-3.5" }),
									label: copy.wind,
									value: forecast ? windText(forecast.current.wind, unit, lang) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SunMedium, { className: "size-3.5" }),
									label: copy.uv,
									value: uvText(today?.uv ?? null)
								})
							]
						}),
						today ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stat stat-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sunrise, {
									className: "size-4 text-accent",
									"aria-hidden": "true"
								}), clockFromIso(today.sunrise, lang)]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sunset, {
									className: "size-4 text-accent",
									"aria-hidden": "true"
								}), clockFromIso(today.sunset, lang)]
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-2 text-sm font-medium",
							children: copy.hourly
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hour-row",
							children: (forecast?.hourly ?? []).map((point) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hour-card",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted",
										children: hourLabel(point.time, lang)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherGlyph, {
										code: point.code,
										isDay: point.isDay,
										className: "size-5"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm font-medium tabular-nums",
										children: [tempOf(point.temp, unit), "°"]
									})
								]
							}, point.time))
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "panel",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "px-1 py-2 text-sm font-medium",
								children: copy.daily
							}), (forecast?.daily ?? []).map((day, index) => {
								const start = (day.min - weekMin) / span * 100;
								const width = Math.max(8, (day.max - day.min) / span * 100);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "day-row",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "truncate text-sm",
											children: dayName(day.date, index, lang)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherGlyph, {
											code: day.code,
											isDay: true,
											className: "size-4"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-center text-xs text-muted tabular-nums",
											children: [tempOf(day.min, unit), "°"]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "range",
											"aria-hidden": "true",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { style: {
												insetInlineStart: `${start}%`,
												width: `${Math.min(width, 100 - start)}%`
											} })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "text-center text-xs font-medium tabular-nums",
											children: [tempOf(day.max, unit), "°"]
										})
									]
								}, day.date);
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "dock",
				"aria-label": copy.scenes,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "dock-scroll",
					role: "radiogroup",
					"aria-label": copy.scenes,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "scene-btn icon-only",
							"aria-pressed": playing,
							"aria-label": playing ? copy.tourStop : copy.tour,
							onClick: togglePlay,
							children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "scene-btn",
							role: "radio",
							"aria-checked": sceneOverride === null,
							onClick: () => pickScene(null),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("i", { className: "live-dot" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: copy.now })]
						}),
						SCENE_META.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "scene-btn",
							role: "radio",
							"aria-checked": sceneOverride === item.id,
							onClick: () => pickScene(item.id),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SceneIcon, { id: item.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "ar" ? item.ar : item.en })]
						}, item.id))
					]
				})
			}),
			sheet ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CitySheet, {
				lang,
				recent: recent.filter((item) => item.id !== place.id),
				onClose: () => setSheet(false),
				onChoose: choose
			}) : null
		]
	});
}
function Stat({ icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "stat",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "inline-flex items-center gap-1 text-xs text-muted",
			children: [icon, label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-lg font-medium tabular-nums",
			children: value
		})]
	});
}
function CitySheet({ lang, recent, onClose, onChoose }) {
	const copy = copyOf(lang);
	const [query, setQuery] = (0, import_react.useState)("");
	const [results, setResults] = (0, import_react.useState)([]);
	const [note, setNote] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.key === "Escape") onClose();
		};
		window.addEventListener("keydown", onKey);
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		return () => {
			window.removeEventListener("keydown", onKey);
			document.body.style.overflow = previous;
		};
	}, [onClose]);
	(0, import_react.useEffect)(() => {
		const trimmed = query.trim();
		if (trimmed.length < 2) {
			setResults([]);
			return;
		}
		const controller = new AbortController();
		const timer = window.setTimeout(() => {
			searchCities(trimmed, lang, controller.signal).then(setResults).catch((error) => {
				if (error instanceof Error && error.name === "AbortError") return;
				setResults([]);
			});
		}, 280);
		return () => {
			window.clearTimeout(timer);
			controller.abort();
		};
	}, [query, lang]);
	async function locate() {
		if (!navigator.geolocation) {
			setNote(copy.geoFailed);
			return;
		}
		setNote(copy.geoWorking);
		navigator.geolocation.getCurrentPosition(async (position) => {
			onChoose(await reversePlace(position.coords.latitude, position.coords.longitude, lang).catch(() => null) ?? {
				id: `${position.coords.latitude.toFixed(2)},${position.coords.longitude.toFixed(2)}`,
				name: copy.myLocation,
				country: "",
				latitude: position.coords.latitude,
				longitude: position.coords.longitude,
				timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC"
			});
		}, () => setNote(copy.geoDenied), {
			enableHighAccuracy: false,
			timeout: 8e3,
			maximumAge: 6e4
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "sheet-back",
		onClick: onClose,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "sheet",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": copy.search,
			onClick: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-3 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-medium",
						children: copy.search
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "chip icon-only",
						"aria-label": copy.close,
						onClick: onClose,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
					onSubmit: (event) => {
						event.preventDefault();
						const first = results[0];
						if (first) onChoose(first);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "search-wrap",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {
							className: "size-4",
							"aria-hidden": "true"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "city-input",
							autoFocus: true,
							value: query,
							placeholder: copy.searchPh,
							"aria-label": copy.search,
							onChange: (event) => setQuery(event.target.value)
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "chip mt-3",
					onClick: () => void locate(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Locate, {
						className: "size-4",
						"aria-hidden": "true"
					}), copy.locate]
				}),
				note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: note
				}) : null,
				query.trim().length >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "city-list",
					children: [results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "text-sm text-muted",
						children: copy.noResults
					}) : null, results.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "city-hit",
						onClick: () => onChoose(item),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: item.country
						})]
					}) }, item.id))]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					recent.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 mt-4 text-sm text-muted",
						children: copy.recent
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "city-list",
						children: recent.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "city-hit",
							onClick: () => onChoose(item),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: placeTitle(item, lang) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: placeCountry(item, lang)
							})]
						}) }, item.id))
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 mt-4 text-sm text-muted",
						children: copy.cities
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "city-list",
						children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "city-hit",
							onClick: () => onChoose(toPlace(preset, lang)),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: lang === "ar" ? preset.nameAr : preset.nameEn }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: lang === "ar" ? preset.countryAr : preset.countryEn
							})]
						}) }, preset.id))
					})
				] })
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WeatherApp, {});
}
//#endregion
export { Home as component };
